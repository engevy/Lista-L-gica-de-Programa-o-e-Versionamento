// Algoritmo 11 — Exibir uma mensagem na tela.
fun main() {
    print("Aprendendo Algoritmo!!!")
}
