// Algoritmo 14 — Colocar a quebra de linha no final da primeira mensagem.
fun main() {
    print("Aprendendo Algoritmo!!!\n")
    print("Com Anita e Guto")
}
