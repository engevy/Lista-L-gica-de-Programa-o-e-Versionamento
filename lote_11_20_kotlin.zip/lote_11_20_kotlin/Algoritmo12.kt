// Algoritmo 12 — Exibir duas mensagens sem quebra de linha automática.
fun main() {
    print("Aprendendo Algoritmo!!!")
    print("Com Anita e Guto")
}
