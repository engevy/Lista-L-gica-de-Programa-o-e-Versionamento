# Lote 11–20 — Kotlin

Implementação dos algoritmos 11 a 20 do livro *Introdução à programação: 500 algoritmos resolvidos*, de Anita Lopes e Guto Garcia, adaptados para Kotlin.

## Conteúdos praticados

| Algoritmos | Conteúdo |
|---|---|
| 11–15 | Saída de dados, `print` e quebras de linha (`\n`) |
| 16–18 | Variáveis, atribuição e exibição de expressões |
| 19 | Funções matemáticas, conversão e formatação numérica |
| 20 | Strings: tamanho, concatenação, cópia, seleção de caracteres e trechos |

## Como compilar e executar

Cada arquivo possui seu próprio `main`, portanto compile um arquivo por vez:

```bash
kotlinc Algoritmo11.kt -include-runtime -d Algoritmo11.jar
java -jar Algoritmo11.jar
```

Troque `11` pelo número do algoritmo desejado. O algoritmo 20 solicita duas palavras pelo terminal.

## Observações de adaptação

- O comando `imprima` do livro foi adaptado principalmente para `print`, pois não acrescenta quebra de linha automaticamente. As quebras aparecem onde o algoritmo usa `\\n`.
- No algoritmo 19, `realint` usa `Math.rint`, pois os exemplos do livro mostram arredondamento de empate para o inteiro par (por exemplo, 6,5 → 6). A função `formatar` trunca as casas decimais; o `+0,001` no exemplo de potência do livro é compatível com esse comportamento.
- No algoritmo 20, o código segue as funções aplicadas à variável `c` no pseudocódigo. A saída-exemplo impressa no livro parece divergir em alguns pontos: para a entrada `TESTANDO`, `strult(c)` deve retornar `O` e os três últimos caracteres devem ser `NDO`, embora o exemplo apresente resultados que parecem vir da segunda palavra (`UAL`). Além disso, a linha chama o resultado de “terceiro elemento”, mas o comentário diz que o índice 3 seleciona o 4º caractere. O código segue o índice 3 e mantém o rótulo do enunciado. Essas divergências foram preservadas como observação, não reproduzidas como resultados incorretos no código.

## Teste rápido

Compile os arquivos individualmente. Para o algoritmo 20, uma entrada de teste é:

```text
TESTANDO
UAL
```

## Commit deste lote

Depois de conferir os dez arquivos e testar os programas no seu ambiente, execute na raiz do repositório:

```bash
git add .
git commit -m "feat: algoritmos 11-20 - saída, variáveis, funções matemáticas e strings"
```

Este é o primeiro commit do trabalho (questões 11–20). O próximo deverá abranger exatamente 21–30.
