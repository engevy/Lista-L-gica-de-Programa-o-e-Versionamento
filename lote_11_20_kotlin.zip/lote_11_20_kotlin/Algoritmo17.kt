// Algoritmo 17 — Exibir uma mensagem junto com o valor de uma variável.
fun main() {
    val x = 10
    print("Valor de x    $x")
}
